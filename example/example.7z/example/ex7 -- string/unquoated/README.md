# NOTICE
> [!WARNING]
> Not all identifiers are parsed as unquoted strings:
> 
> - [CSS color names](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value#Color_keywords) are parsed as [colors](https://sass-lang.com/documentation/values/colors).
> - `null` is parsed as [Sass’s `null` value](https://sass-lang.com/documentation/values/null).
> - `true` and `false` are parsed as [Booleans](https://sass-lang.com/documentation/values/booleans).
> - `not`, `and`, and `or` are parsed as [Boolean operators](https://sass-lang.com/documentation/operators/boolean).
> 
> Because of this, it’s generally a good idea to write quoted strings unless you’re specifically writing the value of a CSS property that uses unquoted strings.