# reference
## guide reference
+ See [`Interpolation in SCSS`](https://sass-lang.com/documentation/interpolation/)
