# NOTICE
> [!WARNING]
> interpolation in SassScript always returns an unquoted string, even interpolating a quaoted string (such as `unquoted: #{"string"};`).

> [!WARNING]
> It’s almost always a bad idea to use interpolation with numbers. 
> 
> Interpolation returns unquoted strings that can’t be used for any further math, 
> 
> and it avoids Sass’s built-in safeguards to ensure that units are used correctly.
> 
> Sass has powerful [unit arithmetic](https://sass-lang.com/documentation/values/numbers#units) that you can use instead. 
> 
> For example, instead of writing `#{$width}px`, write `$width * 1px`
> 
> Or better yet, declare the `$width` variable in terms of `px` to begin with. That way if `$width` already has units, you’ll get a nice error message instead of compiling bogus CSS.

> [!TIP]
> While it’s tempting to use this feature to convert quoted strings to unquoted strings, 
>
> it’s a lot clearer to use the [`string.unquote()` function](https://sass-lang.com/documentation/modules/string#unquote). 
> 
> Instead of `#{$string}`, write `string.unquote($string)`!