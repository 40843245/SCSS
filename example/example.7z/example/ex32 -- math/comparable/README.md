# NOTICE
> [!NOTE]
> `comparable` is a global function that is alias of `math.compatible` function.