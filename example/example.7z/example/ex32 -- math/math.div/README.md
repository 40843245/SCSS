# NOTICE
> [!NOTE]
> For backwards-compatibility purposes, this returns the _exact same result_ as [the deprecated `/` operator](https://sass-lang.com/documentation/breaking-changes/slash-div), 
> including concatenating two strings with a `/` character between them. 
> However, this behavior will be removed eventually and shouldn’t be used in new stylesheets.