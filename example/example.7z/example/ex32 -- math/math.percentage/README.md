# Fun Fact
> [!NOTE]
> This function is identical to `$number * 100%`.