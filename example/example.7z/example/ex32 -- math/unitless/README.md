# NOTICE
> [!NOTE]
> `unitless` is a global function that is alias of `math.is-unitless` function.