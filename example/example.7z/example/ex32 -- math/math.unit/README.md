# NOTICE
> [!WARNING]
> This function is intended for debugging; 
> 
> NOT for developing
> 
> its output format is not guaranteed to be consistent across Sass versions or implementations.