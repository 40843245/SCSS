# NOTICE
> [!WARNING]
> The global name of this function is `compa**ra**ble`, 
> 
> but when it was added to the `sass:math` module the name was changed to `compa**ti**ble` to more clearly convey what the function does.