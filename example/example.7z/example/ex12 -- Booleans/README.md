# NOTICE
> [!NOTE]
> Anywhere `true` or `false` are allowed, you can use other values as well. 
> 
> The values `false` and [`null`](https://sass-lang.com/documentation/values/null) are _falsey_, which means Sass considers them to indicate falsehood and cause conditions to fail. Every other value is considered _truthy_, so Sass considers them to work like `true` and cause conditions to succeed.