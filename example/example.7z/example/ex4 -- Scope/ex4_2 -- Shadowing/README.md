# NOTICE
> [!NOTE]
> The `!global` flag may only be used to set a variable that has already been declared at the top level of a file. 
> 
> It _may not_ be used to declare a new variable.