# NOTICE
> [!NOTE]
> Variables in flow control scope can assign to existing variables in the outer scope, 
>
> but new variables declared in flow control scope won’t be accessible in the outer scope. 
> 
> Make sure the variable is already declared before you assign to it, even if you need to declare it as `null`.