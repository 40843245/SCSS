# prequisite
I assume that you are familiar with CSS. If you are not familiar with CSS, you can visit [example code of `CSS` repo](https://github.com/40843245/CSS/tree/main/example)