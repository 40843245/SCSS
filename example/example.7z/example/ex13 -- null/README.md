# NOTICE
> [!NOTE]
> The value `null` is the only value of its type. 
>
> It represents the absence of a value, and is often returned by functions to indicate the lack of a result.

> [!WARNING]
> If a list contains a `null`, that `null` is omitted from the generated CSS.
> 
> For more details, see `null ex2.scss`.

> [!WARNING]
> If a property value is `null`, that property is omitted entirely. 
>
> For more details, see `null ex3.scss`.

> [!WARNING]
> `null` is also `falsey`.