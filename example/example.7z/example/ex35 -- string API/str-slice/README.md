# NOTICE
> [!NOTE]
> `str-slice` is a global function with alias of `string.slice` function.