# NOTICE
> [!NOTE]
> `str-insert` is a global function with alias of `string.insert` function.