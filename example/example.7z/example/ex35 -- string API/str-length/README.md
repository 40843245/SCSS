# NOTICE
> [!NOTE]
> `str-length` is a global function with alias of `string.length` function.