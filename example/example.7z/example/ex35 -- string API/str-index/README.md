# NOTICE
> [!NOTE]
> `str-index` is a global function with alias of `string.index` function.