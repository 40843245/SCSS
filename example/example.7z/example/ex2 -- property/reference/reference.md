# reference
## guide reference
+ See [`Variable in SCSS`](https://sass-lang.com/documentation/variables/)
