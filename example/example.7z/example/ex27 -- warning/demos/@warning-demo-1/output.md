# output
The exact format of the debug message varies from implementation to implementation. This is what it looks like in Dart Sass:

```
Warning: Unknown prefix wekbit.
    example.scss 6:7   prefix()
    example.scss 16:3  root stylesheet
```