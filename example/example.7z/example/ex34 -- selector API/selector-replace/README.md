# NOTICE
> [!NOTE]
> `selector-replace` is a global function with alias of `selector.replace` function.