# NOTICE
> [!NOTE]
> `simple-selectors` is a global function with alias of `selector.simple-selectors` function.