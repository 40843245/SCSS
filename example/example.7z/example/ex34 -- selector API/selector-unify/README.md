# NOTICE
> [!NOTE]
> `selector-unify` is a global function with alias of `selector.unify` function.