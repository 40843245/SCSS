# NOTICE
> [!NOTE]
> `selector-parse` is a global function with alias of `selector.parse` function.