# NOTICE
> [!NOTE]
> `selector-append` is a global function with alias of `selector.append` function.