# NOTICE
> [!NOTE]
> `selector-extend` is a global function with alias of `selector.extend` function.