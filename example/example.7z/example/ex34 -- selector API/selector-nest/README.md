# NOTICE
> [!NOTE]
> `selector-nest` is a global function with alias of `selector.nest` function.