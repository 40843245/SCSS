# NOTICE
> [!NOTE] 
> Numeric operators automatically convert between compatible units.

> [!NOTE]
> Unitless numbers can be compared with any number. They’re automatically converted to that number’s unit.

> [!NOTE]
> Numbers with incompatible units can’t be addition, subtraction, or modulo.
> 
> ```
> @debug 100px + 10s; // Error: Incompatible units px and s.
> ```

> [!WARNING]
> About `-`, it may be negation or subtraction.
> 
> The different meanings of `-` in Sass take precedence in the following order:
> 
> 1. `-` as part of an identifier. The only exception are units; Sass normally allows any valid identifier to be used as an identifier, 
> 
> but units may > not contain a hyphen followed by a digit.
> 2. `-` between an expression and a literal number with no whitespace, which is parsed as subtraction.
> 
> 3. `-` at the beginning of a literal number, which is parsed as a negative number.
> 
> 4. `-` between two numbers regardless of whitespace, which is parsed as subtraction.
> 
> 5. `-` before a value other than a literal number, which is parsed as unary negation.

> [!WARNING]
> About division, 
> 
> although Sass does support the use of / as a division operator, this is deprecated and will be removed in a future version.
> 
> Use `math.div` function instead.

> [!WARNING]
> About division,
> 
> The `/` operator can return `Slash-Separated Value` in some case
>
> So, use `math.div` function again instead.

> [!NOTE]
> To force to return `Slash-Separated Value`, one can use `list.slash` function.