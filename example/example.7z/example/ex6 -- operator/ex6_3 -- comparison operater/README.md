# NOTICE
> [!NOTE]
> Relational operators determine whether numbers are larger or smaller than one another. 
> 
> They automatically convert between compatible units.

> [!NOTE]
> Unitless numbers can be compared with any number. They’re automatically converted to that number’s unit.

> [!NOTE]
> Numbers with incompatible units can’t be compared.
> 
> ```
> @debug 100px > 10s; // Error: Incompatible units px and s.
> ```