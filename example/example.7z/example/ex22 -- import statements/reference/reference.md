# reference
## guide reference
I can NOT search results in SCSS website with `@namespace` keyword in query search box.

Thus, I will NOT provide links about SCSS, but will provide links about native CSS.

+ See [`@namespace in native CSS (MDN official website)`](https://developer.mozilla.org/en-US/docs/Web/CSS/@namespace)

## code reference
Same as above.