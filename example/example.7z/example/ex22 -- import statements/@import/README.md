# NOTICE
> [!WARNING]
> As of Dart Sass 1.80.0, the @import rule is deprecated and will be removed from the language in Dart Sass 3.0.0. Prefer the @use rule instead.

> [!NOTE]
> What’s Wrong With `@import`?
> 
> The `@import` rule has a number of serious issues:
> 
> - `@import` makes all variables, mixins, and functions globally accessible. This makes it very difficult for people (or tools) to tell where anything is defined.  
> 
> - Because everything’s global, libraries must add a prefix to all their members to avoid naming collisions.
>
> - [`@extend` rules](https://sass-lang.com/documentation/at-rules/extend) are also global, which makes it difficult to predict which style rules will be extended.    
> 
> - Each stylesheet is executed and its CSS emitted _every time_ it’s `@import`ed, which increases compilation time and produces bloated output.
>
> - There was no way to define private members or placeholder selectors that were inaccessible to downstream stylesheets.
>   
> The new module system and the `@use` rule address all these problems.