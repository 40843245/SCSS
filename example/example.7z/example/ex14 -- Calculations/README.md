# NOTICE
> [!WARNING]
> The syntax of `calc()`, `clamp()`, `min()`, and `max()` etc functions is same as native CSS.
> 
> But there are different behaviours between functions in SCSS and those in native CSS 
> 
> since features of SCSS variables and functions.