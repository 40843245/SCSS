# Nesting
## introduction
In native CSS, you can NOT define another css element inside a css element.

But in SCSS, you can.