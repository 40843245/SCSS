# reference
## guide reference
+ See [`Styling rules in SCSS#nesting](https://sass-lang.com/documentation/style-rules/#nesting)

+ See [`Nesting for parent selectors`](https://sass-lang.com/documentation/style-rules/parent-selector/)
