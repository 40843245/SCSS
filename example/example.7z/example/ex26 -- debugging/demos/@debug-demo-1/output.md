# output
The exact format of the debug message varies from implementation to implementation. This is what it looks like in Dart Sass:

```
test.scss:3 Debug: divider offset: 132px
```