# NOTICE
> [!NOTE]
> This function is a temporary solution for creating slash-separated lists. 
>
> Eventually, they’ll be written literally with slashes, as in `1px / 2px / solid`, 
> 
> but for the time being [slashes are used for division](https://sass-lang.com/documentation/breaking-changes/slash-div)
> 
> so Sass can’t use them for new syntax until the old syntax is removed.